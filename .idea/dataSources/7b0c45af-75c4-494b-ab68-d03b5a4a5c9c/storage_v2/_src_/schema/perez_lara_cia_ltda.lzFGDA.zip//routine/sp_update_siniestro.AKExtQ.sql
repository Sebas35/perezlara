create
    definer = root@localhost procedure sp_update_siniestro(IN _id_siniestro int, IN _fecha date, IN _titulo varchar(45),
                                                           IN _descripcion text, IN _monto double,
                                                           IN _codigo_poliza int)
BEGIN
    UPDATE siniestro
    SET fecha         = _fecha,
        titulo        = _titulo,
        descripcion   = _descripcion,
        monto         = _monto,
        codigo_poliza = _codigo_poliza
    WHERE id_siniestro = _id_siniestro;
END;

