create
    definer = root@localhost procedure sp_delete_siniestro(IN _id_siniestro int)
BEGIN
    UPDATE siniestro
    SET estado = 2
    WHERE id_siniestro = _id_siniestro;
END;

