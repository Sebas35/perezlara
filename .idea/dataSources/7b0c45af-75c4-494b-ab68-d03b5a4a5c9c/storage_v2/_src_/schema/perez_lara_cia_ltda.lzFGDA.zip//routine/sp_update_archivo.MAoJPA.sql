create
    definer = root@localhost procedure sp_update_archivo(IN _id_archivo varchar(150), IN _nombre_archivo varchar(45))
BEGIN
    UPDATE archivo
    SET nombre_archivo = _nombre_archivo
    WHERE id_archivo = _id_archivo;
END;

