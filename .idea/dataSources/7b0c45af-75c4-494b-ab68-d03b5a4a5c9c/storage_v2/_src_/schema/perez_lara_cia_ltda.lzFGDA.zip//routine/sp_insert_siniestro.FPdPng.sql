create
    definer = root@localhost procedure sp_insert_siniestro(IN _fecha date, IN _titulo varchar(45), IN _descripcion text,
                                                           IN _monto double, IN _codigo_poliza int)
BEGIN
    INSERT INTO siniestro (fecha, titulo, descripcion, monto, codigo_poliza)
    VALUES (_fecha, _titulo, _descripcion, _monto, _codigo_poliza);
    SELECT LAST_INSERT_ID();
END;

