create definer = root@localhost view view_cotizacion as
select `perez_lara_cia_ltda`.`cotizacion`.`id_cotizacion`                                                           AS `No. Cotizacion`,
       `perez_lara_cia_ltda`.`cotizacion`.`fecha`                                                                   AS `Fecha`,
       `perez_lara_cia_ltda`.`cotizacion`.`documento_cliente`                                                       AS `Documento`,
       concat(`c`.`primer_nombre`, ' ', coalesce(`c`.`segundo_nombre`, ''), ' ', `c`.`primer_apellido`, ' ',
              coalesce(`c`.`segundo_apellido`, ''))                                                                 AS `Cliente`,
       `perez_lara_cia_ltda`.`cotizacion`.`seguro`                                                                  AS `id_seguro`,
       `s`.`seguro`                                                                                                 AS `Seguro`,
       group_concat(distinct `a2`.`id_aseguradora` separator ',')                                                   AS `id_aseguradora`,
       group_concat(distinct `a2`.`logo` separator ',')                                                             AS `Aseguradora`,
       group_concat(distinct `a2`.`aseguradora` separator ',')                                                      AS `nombre_aseguradora`,
       group_concat(distinct `a`.`id_aseguradora_cotizante` order by `a`.`aseguradora` ASC separator
                    ',')                                                                                            AS `id_aseguradora_cotizante`,
       (select `a`.`id_aseguradora_cotizante`
        from `perez_lara_cia_ltda`.`aseguradora_cotizante` `a`
        where `a`.`cotizacion` = `perez_lara_cia_ltda`.`cotizacion`.`id_cotizacion`
          and `a`.`aceptado` = 1)                                                                                   AS `opcion_seleccionada`,
       group_concat(`cc`.`precio` order by `a`.`aseguradora` ASC, `cc`.`id_cobertura_cotizacion` ASC separator
                    ',')                                                                                            AS `Precio`,
       group_concat(`ac`.`deducible` order by `ac`.`id_aseguradora` ASC, `cc`.`id_cobertura_cotizacion` ASC separator
                    ',')                                                                                            AS `Deducible`,
       group_concat(distinct `cc`.`id_cobertura` separator ',')                                                     AS `id_cobertura`,
       group_concat(distinct `c2`.`cobertura` order by `c2`.`id_cobertura` ASC separator
                    ',')                                                                                            AS `nombre_cobertura`,
       `perez_lara_cia_ltda`.`cotizacion`.`valor_asegurado`                                                         AS `Valor asegurado`,
       (select group_concat(`ac`.`valor_prima` order by `ac`.`aseguradora` ASC separator ',')
        from `perez_lara_cia_ltda`.`aseguradora_cotizante` `ac`
        where `ac`.`cotizacion` = `perez_lara_cia_ltda`.`cotizacion`.`id_cotizacion`)                               AS `Valor prima`,
       `p`.`codigo`                                                                                                 AS `poliza`,
       `e`.`estado`                                                                                                 AS `Estado`,
       coalesce(`perez_lara_cia_ltda`.`cotizacion`.`fecha_actualizacion`,
                '-')                                                                                                AS `Fecha de actualización`
from (((((((((`perez_lara_cia_ltda`.`cotizacion` join `perez_lara_cia_ltda`.`cliente` `c`
              on (`perez_lara_cia_ltda`.`cotizacion`.`documento_cliente` =
                  `c`.`documento`)) join `perez_lara_cia_ltda`.`seguro` `s`
             on (`perez_lara_cia_ltda`.`cotizacion`.`seguro` = `s`.`id_seguro`)) join `perez_lara_cia_ltda`.`aseguradora_cotizante` `a`
            on (`perez_lara_cia_ltda`.`cotizacion`.`id_cotizacion` = `a`.`cotizacion`)) join `perez_lara_cia_ltda`.`aseguradora` `a2`
           on (`a`.`aseguradora` = `a2`.`id_aseguradora`)) join `perez_lara_cia_ltda`.`cobertura_cotizacion` `cc`
          on (`a`.`id_aseguradora_cotizante` = `cc`.`id_aseguradora_cotizante`)) join `perez_lara_cia_ltda`.`cobertura` `c2`
         on (`cc`.`id_cobertura` = `c2`.`id_cobertura`)) join `perez_lara_cia_ltda`.`aseguradora_cobertura` `ac`
        on (`a2`.`id_aseguradora` = `ac`.`id_aseguradora`)) join `perez_lara_cia_ltda`.`estado` `e`
       on (`perez_lara_cia_ltda`.`cotizacion`.`estado` = `e`.`id_estado`)) left join `perez_lara_cia_ltda`.`poliza` `p`
      on (`perez_lara_cia_ltda`.`cotizacion`.`id_cotizacion` = `p`.`cotizacion`))
where `cc`.`id_cobertura` = `ac`.`id_cobertura`
group by `perez_lara_cia_ltda`.`cotizacion`.`id_cotizacion`;

