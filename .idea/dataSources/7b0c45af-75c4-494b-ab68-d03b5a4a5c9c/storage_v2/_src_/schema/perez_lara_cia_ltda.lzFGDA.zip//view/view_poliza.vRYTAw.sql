create definer = root@localhost view view_poliza as
select `perez_lara_cia_ltda`.`poliza`.`codigo`            AS `Codigo póliza`,
       `perez_lara_cia_ltda`.`poliza`.`fecha_registro`    AS `Fecha`,
       `c`.`documento_cliente`                            AS `Documento`,
       concat(`c2`.`primer_nombre`, ' ', coalesce(`c2`.`segundo_nombre`, ''), ' ', `c2`.`primer_apellido`, ' ',
              coalesce(`c2`.`segundo_apellido`, ''))      AS `Cliente`,
       `s`.`seguro`                                       AS `Seguro`,
       `a`.`aseguradora`                                  AS `nombre_aseguradora`,
       `a`.`logo`                                         AS `Aseguradora`,
       `ac`.`id_aseguradora_cotizante`                    AS `id_aseguradora_cotizante`,
       `a2`.`id_archivo`                                  AS `id_archivo`,
       `a2`.`nombre_archivo`                              AS `nombre_archivo`,
       `perez_lara_cia_ltda`.`poliza`.`fecha_inicio`      AS `Fecha de inicio`,
       `perez_lara_cia_ltda`.`poliza`.`fecha_vencimiento` AS `Fecha de vencimiento`,
       `c`.`valor_asegurado`                              AS `Valor asegurado`,
       `ac`.`valor_prima`                                 AS `Valor prima`,
       `perez_lara_cia_ltda`.`poliza`.`fecha_pago`        AS `Fecha de pago`,
       `perez_lara_cia_ltda`.`poliza`.`cantidad_meses`    AS `Cantidad de meses`,
       `e`.`estado`                                       AS `Estado`,
       coalesce(max(`a3`.`fecha`), '-')                   AS `Fecha de actualización`
from ((((((((`perez_lara_cia_ltda`.`poliza` join `perez_lara_cia_ltda`.`cotizacion` `c`
             on (`perez_lara_cia_ltda`.`poliza`.`cotizacion` = `c`.`id_cotizacion`)) join `perez_lara_cia_ltda`.`aseguradora_cotizante` `ac`
            on (`c`.`id_cotizacion` = `ac`.`cotizacion`)) join `perez_lara_cia_ltda`.`aseguradora` `a`
           on (`ac`.`aseguradora` = `a`.`id_aseguradora`)) join `perez_lara_cia_ltda`.`seguro` `s`
          on (`c`.`seguro` = `s`.`id_seguro`)) join `perez_lara_cia_ltda`.`cliente` `c2`
         on (`c`.`documento_cliente` = `c2`.`documento`)) join `perez_lara_cia_ltda`.`estado` `e`
        on (`perez_lara_cia_ltda`.`poliza`.`estado` = `e`.`id_estado`)) join `perez_lara_cia_ltda`.`archivo` `a2`
       on (`perez_lara_cia_ltda`.`poliza`.`codigo` = `a2`.`id_poliza`)) left join `perez_lara_cia_ltda`.`anexo` `a3`
      on (`perez_lara_cia_ltda`.`poliza`.`codigo` = `a3`.`codigo_poliza`))
where `ac`.`aceptado` = 1
group by `perez_lara_cia_ltda`.`poliza`.`codigo`
order by `perez_lara_cia_ltda`.`poliza`.`codigo`;

