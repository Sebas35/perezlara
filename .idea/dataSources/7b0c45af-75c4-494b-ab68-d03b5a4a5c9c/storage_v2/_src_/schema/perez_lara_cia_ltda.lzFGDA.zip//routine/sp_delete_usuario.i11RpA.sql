create
    definer = root@localhost procedure sp_delete_usuario(IN _documento varchar(20))
BEGIN
    DELETE
    FROM usuario
    WHERE documento = _documento;
END;

