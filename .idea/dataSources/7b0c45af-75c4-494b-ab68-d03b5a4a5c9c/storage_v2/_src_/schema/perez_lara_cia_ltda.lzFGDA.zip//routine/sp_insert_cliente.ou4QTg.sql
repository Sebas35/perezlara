create
    definer = root@localhost procedure sp_insert_cliente(IN _documento varchar(20), IN _primer_nombre varchar(45),
                                                         IN _segundo_nombre varchar(45),
                                                         IN _primer_apellido varchar(45),
                                                         IN _segundo_apellido varchar(45), IN _fecha_nacimiento date,
                                                         IN _email varchar(76), IN _telefono1 varchar(15),
                                                         IN _telefono2 varchar(15), IN _direccion1 varchar(100),
                                                         IN _direccion2 varchar(100), IN _tipo_documento int,
                                                         IN _ciudad int)
BEGIN
    INSERT INTO cliente (documento, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, fecha_nacimiento,
                         email, telefono1, telefono2, direccion1, direccion2, tipo_documento, ciudad)
    VALUES (_documento, _primer_nombre, _segundo_nombre, _primer_apellido, _segundo_apellido, _fecha_nacimiento, _email,
            _telefono1, _telefono2, _direccion1, _direccion2, _tipo_documento, _ciudad);
END;

