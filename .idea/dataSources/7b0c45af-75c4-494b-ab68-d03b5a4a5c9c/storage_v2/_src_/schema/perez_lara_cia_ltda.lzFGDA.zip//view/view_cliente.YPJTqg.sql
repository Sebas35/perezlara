create definer = root@localhost view view_cliente as
select `t`.`id_tipo_documento`                                                  AS `id_tipo_documento`,
       `t`.`descripcion_documento`                                              AS `descripcion_documento`,
       `t`.`abreviacion`                                                        AS `abreviacion`,
       `perez_lara_cia_ltda`.`cliente`.`documento`                              AS `documento`,
       concat(`perez_lara_cia_ltda`.`cliente`.`primer_nombre`, ' ',
              coalesce(`perez_lara_cia_ltda`.`cliente`.`segundo_nombre`, ''))   AS `Nombres`,
       concat(`perez_lara_cia_ltda`.`cliente`.`primer_apellido`, ' ',
              coalesce(`perez_lara_cia_ltda`.`cliente`.`segundo_apellido`, '')) AS `Apellidos`,
       `d`.`id_departamento`                                                    AS `id_departamento`,
       `d`.`departamento`                                                       AS `Departamento`,
       `perez_lara_cia_ltda`.`cliente`.`ciudad`                                 AS `id_ciudad`,
       `c`.`ciudad`                                                             AS `Ciudad`,
       `perez_lara_cia_ltda`.`cliente`.`direccion1`                             AS `direccion1`,
       `perez_lara_cia_ltda`.`cliente`.`direccion2`                             AS `direccion2`,
       `perez_lara_cia_ltda`.`cliente`.`fecha_nacimiento`                       AS `Fecha de nacimiento`,
       `perez_lara_cia_ltda`.`cliente`.`email`                                  AS `Email`,
       `perez_lara_cia_ltda`.`cliente`.`telefono1`                              AS `telefono1`,
       `perez_lara_cia_ltda`.`cliente`.`telefono2`                              AS `telefono2`,
       `perez_lara_cia_ltda`.`cliente`.`fecha_ingreso`                          AS `Fecha ingreso`,
       `e`.`estado`                                                             AS `Estado`
from ((((`perez_lara_cia_ltda`.`cliente` join `perez_lara_cia_ltda`.`tipo_documento` `t`
         on (`perez_lara_cia_ltda`.`cliente`.`tipo_documento` =
             `t`.`id_tipo_documento`)) join `perez_lara_cia_ltda`.`ciudad` `c`
        on (`perez_lara_cia_ltda`.`cliente`.`ciudad` = `c`.`id_ciudad`)) join `perez_lara_cia_ltda`.`departamento` `d`
       on (`c`.`departamento` = `d`.`id_departamento`)) join `perez_lara_cia_ltda`.`estado` `e`
      on (`perez_lara_cia_ltda`.`cliente`.`estado` = `e`.`id_estado`))
where `perez_lara_cia_ltda`.`cliente`.`estado` <> 2;

