create
    definer = root@localhost procedure sp_insert_cobertura_cotizacion(IN _id_aseguradora_cotizante int,
                                                                      IN _id_cobertura int, IN _precio double)
BEGIN
    INSERT INTO cobertura_cotizacion (id_aseguradora_cotizante, id_cobertura, precio)
    VALUES (_id_aseguradora_cotizante, _id_cobertura, _precio);
END;

