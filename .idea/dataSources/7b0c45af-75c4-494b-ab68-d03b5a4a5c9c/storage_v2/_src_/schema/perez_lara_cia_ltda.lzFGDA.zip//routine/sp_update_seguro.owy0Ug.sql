create
    definer = root@localhost procedure sp_update_seguro(IN _id_seguro int, IN _seguro varchar(45), IN _imagen varchar(150))
BEGIN
    UPDATE seguro
    SET seguro = _seguro,
        imagen = _imagen
    WHERE id_seguro = _id_seguro;
END;

