create
    definer = root@localhost procedure sp_update_cotizacion(IN _id_cotizacion int, IN _documento_cliente varchar(20),
                                                            IN _seguro int, IN _valor_asegurado double)
BEGIN
    UPDATE cotizacion
    SET documento_cliente = _documento_cliente,
        seguro            = _seguro,
        valor_asegurado   = _valor_asegurado
    WHERE id_cotizacion = _id_cotizacion;
    DELETE FROM aseguradora_cotizante where cotizacion = _id_cotizacion;
END;

