create
    definer = root@localhost procedure sp_insert_poliza(IN _codigo int, IN _fecha_inicio date,
                                                        IN _fecha_vencimiento date, IN _fecha_pago date,
                                                        IN _cantidad_meses int, IN _id_aseguradora_cotizante int)
BEGIN
    DECLARE id_cotizacion INT;
    SELECT cotizacion
    INTO id_cotizacion
    FROM aseguradora_cotizante
    WHERE id_aseguradora_cotizante = _id_aseguradora_cotizante;
    UPDATE aseguradora_cotizante SET aceptado = 1 WHERE id_aseguradora_cotizante = _id_aseguradora_cotizante;
    INSERT INTO poliza (codigo, fecha_inicio, fecha_vencimiento,
                        fecha_pago, cantidad_meses, meses_restantes, cotizacion)
    VALUES (_codigo, _fecha_inicio, _fecha_vencimiento, _fecha_pago, _cantidad_meses, _cantidad_meses, id_cotizacion);
END;

