create
    definer = root@localhost procedure sp_insert_cotizacion(IN _documento_cliente varchar(20), IN _seguro int,
                                                            IN _valor_asegurado double, IN _usuario varchar(20))
BEGIN
    INSERT INTO cotizacion (documento_cliente, seguro, valor_asegurado, usuario)
    VALUES (_documento_cliente, _seguro, _valor_asegurado, _usuario);
    SELECT LAST_INSERT_ID();
END;

