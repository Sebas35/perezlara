create
    definer = root@localhost procedure sp_delete_seguro(IN _id_seguro int)
BEGIN
    UPDATE seguro_aseguradora
    SET estado = 2
    WHERE seguro = _id_seguro;
END;

