create
    definer = root@localhost procedure sp_insert_aseguradora_cotizante(IN _id_cotizacion int, IN _id_aseguradora int, IN _valor_prima double)
BEGIN
    INSERT INTO aseguradora_cotizante (cotizacion, aseguradora, valor_prima)
    VALUES (_id_cotizacion, _id_aseguradora, _valor_prima);
    SELECT LAST_INSERT_ID();
END;

