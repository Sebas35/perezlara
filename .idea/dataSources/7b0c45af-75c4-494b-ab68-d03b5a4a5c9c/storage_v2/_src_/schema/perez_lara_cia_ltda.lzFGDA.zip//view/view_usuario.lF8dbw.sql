create definer = root@localhost view view_usuario as
select `t`.`id_tipo_documento`                                                  AS `id_tipo_documento`,
       `t`.`descripcion_documento`                                              AS `descripcion_documento`,
       `t`.`abreviacion`                                                        AS `abreviacion`,
       `perez_lara_cia_ltda`.`usuario`.`documento`                              AS `documento`,
       `perez_lara_cia_ltda`.`usuario`.`foto_perfil`                            AS `Foto`,
       concat(`perez_lara_cia_ltda`.`usuario`.`primer_nombre`, ' ',
              coalesce(`perez_lara_cia_ltda`.`usuario`.`segundo_nombre`, ''))   AS `Nombres`,
       concat(`perez_lara_cia_ltda`.`usuario`.`primer_apellido`, ' ',
              coalesce(`perez_lara_cia_ltda`.`usuario`.`segundo_apellido`, '')) AS `Apellidos`,
       `perez_lara_cia_ltda`.`usuario`.`email`                                  AS `Email`,
       `perez_lara_cia_ltda`.`usuario`.`celular`                                AS `Celular`,
       `r`.`id_rol`                                                             AS `id_rol`,
       `r`.`rol`                                                                AS `Rol`
from (((`perez_lara_cia_ltda`.`usuario` join `perez_lara_cia_ltda`.`tipo_documento` `t`
        on (`perez_lara_cia_ltda`.`usuario`.`tipo_documento` =
            `t`.`id_tipo_documento`)) join `perez_lara_cia_ltda`.`rol` `r`
       on (`perez_lara_cia_ltda`.`usuario`.`rol` = `r`.`id_rol`)) join `perez_lara_cia_ltda`.`estado` `e`
      on (`perez_lara_cia_ltda`.`usuario`.`estado` = `e`.`id_estado`))
where `perez_lara_cia_ltda`.`usuario`.`estado` <> 2
order by concat(`perez_lara_cia_ltda`.`usuario`.`primer_nombre`, ' ',
                coalesce(`perez_lara_cia_ltda`.`usuario`.`segundo_nombre`, ''));

