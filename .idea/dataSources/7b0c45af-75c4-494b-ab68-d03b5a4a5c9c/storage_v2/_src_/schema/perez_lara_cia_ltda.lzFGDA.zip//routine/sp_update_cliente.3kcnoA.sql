create
    definer = root@localhost procedure sp_update_cliente(IN _documento_update varchar(20), IN _documento varchar(20),
                                                         IN _primer_nombre varchar(45), IN _segundo_nombre varchar(45),
                                                         IN _primer_apellido varchar(45),
                                                         IN _segundo_apellido varchar(45), IN _fecha_nacimiento date,
                                                         IN _email varchar(76), IN _telefono1 varchar(15),
                                                         IN _telefono2 varchar(15), IN _direccion1 varchar(100),
                                                         IN _direccion2 varchar(100), IN _tipo_documento int,
                                                         IN _ciudad int)
BEGIN
    UPDATE cliente
    SET documento        = _documento,
        primer_nombre    = _primer_nombre,
        segundo_nombre   = _segundo_nombre,
        primer_apellido  = _primer_apellido,
        segundo_apellido = _segundo_apellido,
        fecha_nacimiento = _fecha_nacimiento,
        email            = _email,
        telefono1        = _telefono1,
        telefono2        = _telefono2,
        direccion1       = _direccion1,
        direccion2       = _direccion2,
        tipo_documento   = _tipo_documento,
        ciudad           = _ciudad
    WHERE documento = _documento_update;
END;

