create definer = root@localhost view view_siniestro as
select `perez_lara_cia_ltda`.`siniestro`.`id_siniestro`         AS `No. Referencia`,
       `perez_lara_cia_ltda`.`siniestro`.`fecha`                AS `Fecha`,
       `perez_lara_cia_ltda`.`siniestro`.`codigo_poliza`        AS `Codigo póliza`,
       `vp`.`Cliente`                                           AS `Cliente`,
       `perez_lara_cia_ltda`.`siniestro`.`titulo`               AS `Titulo`,
       `vp`.`Seguro`                                            AS `Seguro`,
       `vp`.`nombre_aseguradora`                                AS `nombre_aseguradora`,
       `vp`.`Aseguradora`                                       AS `Aseguradora`,
       coalesce(`perez_lara_cia_ltda`.`siniestro`.`monto`, '-') AS `Monto`,
       `perez_lara_cia_ltda`.`siniestro`.`descripcion`          AS `Descripción`,
       group_concat(`a2`.`id_archivo` separator ',')            AS `id_archivo`,
       group_concat(`a2`.`nombre_archivo` separator ',')        AS `nombre_archivo`,
       `perez_lara_cia_ltda`.`siniestro`.`estado`               AS `id_estado`,
       `e`.`estado`                                             AS `Estado`,
       coalesce(max(`a3`.`fecha`), '-')                         AS `Fecha de actualización`
from ((((`perez_lara_cia_ltda`.`siniestro` join `perez_lara_cia_ltda`.`view_poliza` `vp`
         on (`perez_lara_cia_ltda`.`siniestro`.`codigo_poliza` =
             `vp`.`Codigo póliza`)) join `perez_lara_cia_ltda`.`estado` `e`
        on (`perez_lara_cia_ltda`.`siniestro`.`estado` = `e`.`id_estado`)) join `perez_lara_cia_ltda`.`archivo` `a2`
       on (`perez_lara_cia_ltda`.`siniestro`.`id_siniestro` = `a2`.`id_siniestro`)) left join `perez_lara_cia_ltda`.`anexo` `a3`
      on (`perez_lara_cia_ltda`.`siniestro`.`id_siniestro` = `a3`.`siniestro`))
group by `perez_lara_cia_ltda`.`siniestro`.`id_siniestro`
order by `perez_lara_cia_ltda`.`siniestro`.`id_siniestro`;

