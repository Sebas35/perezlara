create
    definer = root@localhost procedure sp_update_usuario(IN _documento_update varchar(76), IN _documento varchar(20),
                                                         IN _primer_nombre varchar(45), IN _segundo_nombre varchar(45),
                                                         IN _primer_apellido varchar(45),
                                                         IN _segundo_apellido varchar(45), IN _email varchar(76),
                                                         IN _celular varchar(15), IN _clave varchar(256),
                                                         IN _foto_perfil varchar(150), IN _tipo_documento int,
                                                         IN _rol int)
BEGIN
    UPDATE usuario
    SET documento        = _documento,
        primer_nombre    = _primer_nombre,
        segundo_nombre   = _segundo_nombre,
        primer_apellido  = _primer_apellido,
        segundo_apellido = _segundo_apellido,
        celular          = _celular,
        email            = _email,
        rol              = if(_rol != '', _rol, rol),
        clave            = if(_clave != '', AES_ENCRYPT(_clave, 'colombia123'), clave),
        foto_perfil      = if(_foto_perfil != '', _foto_perfil, foto_perfil),
        tipo_documento   = _tipo_documento
    WHERE documento = _documento_update;
END;

