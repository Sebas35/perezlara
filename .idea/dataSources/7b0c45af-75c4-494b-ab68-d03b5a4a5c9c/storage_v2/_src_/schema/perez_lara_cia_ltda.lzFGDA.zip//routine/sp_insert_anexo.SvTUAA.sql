create
    definer = root@localhost procedure sp_insert_anexo(IN _titulo varchar(45), IN _descripcion text,
                                                       IN _codigo_poliza varchar(11), IN _siniestro varchar(11))
BEGIN
    INSERT INTO anexo (titulo, descripcion, codigo_poliza, siniestro)
    VALUES (_titulo, _descripcion, if(_codigo_poliza != '', _codigo_poliza, null),
            if(_siniestro != '', _siniestro, null));
END;

