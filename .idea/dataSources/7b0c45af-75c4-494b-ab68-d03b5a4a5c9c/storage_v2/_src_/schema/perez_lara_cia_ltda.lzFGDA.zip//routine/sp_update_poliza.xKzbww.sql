create
    definer = root@localhost procedure sp_update_poliza(IN _codigo int, IN _codigo2 int, IN _fecha_inicio date,
                                                        IN _fecha_vencimiento date, IN _fecha_pago date,
                                                        IN _cantidad_meses int, IN _id_aseguradora_cotizante int)
BEGIN
    DECLARE id_cotizacion INT;
    SELECT cotizacion INTO id_cotizacion FROM aseguradora_cotizante WHERE id_aseguradora_cotizante = _id_aseguradora_cotizante;
    UPDATE aseguradora_cotizante SET aceptado = (IF(id_aseguradora_cotizante = _id_aseguradora_cotizante, 1, NULL))
    WHERE cotizacion = id_cotizacion;
    UPDATE poliza
    SET codigo            = _codigo2,
        fecha_inicio      = _fecha_inicio,
        fecha_vencimiento = _fecha_vencimiento,
        fecha_pago        = _fecha_pago,
        meses_restantes   = if((_cantidad_meses - cantidad_meses + meses_restantes) > 0,
                               (_cantidad_meses - cantidad_meses + meses_restantes), 0),
        cantidad_meses    = _cantidad_meses,
        cotizacion        = id_cotizacion
    WHERE codigo = _codigo;
END;

