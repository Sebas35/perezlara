create
    definer = root@localhost procedure sp_update_aseguradora(IN _id_aseguradora int, IN _aseguradora varchar(45),
                                                             IN _logo varchar(150))
BEGIN
    UPDATE aseguradora
    SET aseguradora = _aseguradora,
        logo        = _logo
    WHERE id_aseguradora = _id_aseguradora;
END;

