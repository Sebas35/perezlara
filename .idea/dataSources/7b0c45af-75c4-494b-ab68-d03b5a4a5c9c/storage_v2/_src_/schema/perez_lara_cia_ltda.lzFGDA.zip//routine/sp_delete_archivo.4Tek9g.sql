create
    definer = root@localhost procedure sp_delete_archivo(IN _id_archivo varchar(150))
BEGIN
    DELETE FROM archivo where id_archivo = _id_archivo;
END;

