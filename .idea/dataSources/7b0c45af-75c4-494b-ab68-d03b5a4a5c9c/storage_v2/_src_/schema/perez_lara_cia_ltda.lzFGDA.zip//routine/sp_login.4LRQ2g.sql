create
    definer = root@localhost procedure sp_login(IN _email varchar(76), IN _documento varchar(20),
                                                IN _clave varchar(256))
BEGIN
    SELECT documento, rol
    FROM usuario
    WHERE (email = _email or documento = _documento)
      AND clave = AES_ENCRYPT(_clave, 'colombia123');
END;

