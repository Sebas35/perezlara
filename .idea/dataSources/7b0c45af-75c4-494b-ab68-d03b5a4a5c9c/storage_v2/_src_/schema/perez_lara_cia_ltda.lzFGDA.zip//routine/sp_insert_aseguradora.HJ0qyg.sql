create
    definer = root@localhost procedure sp_insert_aseguradora(IN _aseguradora varchar(45), IN _logo varchar(150))
BEGIN
    INSERT INTO aseguradora (aseguradora, logo)
    VALUES (_aseguradora, _logo);
    SELECT LAST_INSERT_ID();
END;

