create
    definer = root@localhost procedure sp_delete_aseguradora(IN _id_aseguradora int)
BEGIN
    UPDATE seguro_aseguradora
    SET estado = 2
    WHERE aseguradora = _id_aseguradora;
END;

