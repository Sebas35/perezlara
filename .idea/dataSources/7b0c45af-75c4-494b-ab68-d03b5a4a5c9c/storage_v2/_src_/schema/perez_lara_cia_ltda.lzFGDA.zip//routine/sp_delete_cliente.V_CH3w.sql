create
    definer = root@localhost procedure sp_delete_cliente(IN _documento varchar(20))
BEGIN
    UPDATE cliente
    SET estado = 2
    WHERE documento = _documento;
END;

