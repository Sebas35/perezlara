create
    definer = root@localhost procedure sp_insert_archivo(IN _id_archivo varchar(150), IN _nombre_archivo varchar(45),
                                                         IN _id_anexo varchar(11), IN _id_siniestro varchar(11),
                                                         IN _id_poliza varchar(11))
BEGIN
    INSERT INTO archivo (id_archivo, nombre_archivo, id_anexo, id_siniestro, id_poliza)
    VALUES (_id_archivo, _nombre_archivo, if(_id_anexo != '', _id_anexo, null),
            if(_id_siniestro != '', _id_siniestro, null),
            if(_id_poliza != '', _id_poliza, null));
END;

