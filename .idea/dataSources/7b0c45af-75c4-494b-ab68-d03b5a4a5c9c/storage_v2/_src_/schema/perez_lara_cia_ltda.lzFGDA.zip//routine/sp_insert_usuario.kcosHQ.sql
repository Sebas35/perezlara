create
    definer = root@localhost procedure sp_insert_usuario(IN _documento varchar(20), IN _primer_nombre varchar(45),
                                                         IN _segundo_nombre varchar(45),
                                                         IN _primer_apellido varchar(45),
                                                         IN _segundo_apellido varchar(45), IN _email varchar(76),
                                                         IN _celular varchar(15), IN _clave varchar(256),
                                                         IN _foto_perfil varchar(150), IN _tipo_documento int,
                                                         IN _rol int, IN _estado int)
BEGIN
    INSERT INTO usuario (documento, primer_nombre, segundo_nombre, primer_apellido, segundo_apellido, email, celular,
                         clave,
                         foto_perfil, tipo_documento, rol, estado)
    VALUES (_documento, _primer_nombre, _segundo_nombre, _primer_apellido, _segundo_apellido, _email, _celular,
            AES_ENCRYPT(_clave, 'colombia123'), _foto_perfil, _tipo_documento, _rol, _estado);
END;

