create
    definer = root@localhost procedure sp_insert_seguro(IN _seguro varchar(45), IN _imagen varchar(150))
BEGIN
    INSERT INTO seguro (seguro, imagen)
    VALUES (_seguro, _imagen);
END;

