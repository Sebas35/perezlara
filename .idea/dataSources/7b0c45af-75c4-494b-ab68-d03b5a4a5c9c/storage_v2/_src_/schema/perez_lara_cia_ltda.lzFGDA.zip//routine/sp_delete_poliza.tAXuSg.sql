create
    definer = root@localhost procedure sp_delete_poliza(IN _codigo int)
BEGIN
    UPDATE poliza
    SET estado = 2
    WHERE codigo = _codigo;
END;

