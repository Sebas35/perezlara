create
    definer = root@localhost procedure sp_delete_cotizacion(IN _id_cotizacion int)
BEGIN
    UPDATE cotizacion
    SET estado = 2
    WHERE id_cotizacion = _id_cotizacion;
END;

