create
    definer = root@localhost procedure sp_insert_seguro_aseguradora(IN id_seguro int, IN id_aseguradora int)
BEGIN
    INSERT INTO seguro_aseguradora (seguro, aseguradora) 
    VALUES (id_seguro,id_aseguradora); 
END;

