create
    definer = root@localhost procedure sp_inactivate_usuario(IN _documento varchar(20))
BEGIN
    UPDATE usuario
    SET estado = 2
    WHERE documento = _documento;
END;

